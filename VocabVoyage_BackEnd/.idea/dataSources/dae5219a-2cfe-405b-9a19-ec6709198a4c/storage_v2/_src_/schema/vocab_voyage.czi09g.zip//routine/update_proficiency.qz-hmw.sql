create
    definer = root@`%` procedure update_proficiency(IN p_word_id int, IN p_user_id int, IN mem_res int)
BEGIN
    DECLARE current_proficiency INT DEFAULT 0;

    -- 尝试获取当前熟练度，如果不存在则设置为默认值
    SELECT proficiency INTO current_proficiency
    FROM memory
    WHERE user_id = p_user_id AND word_id = p_word_id;

    -- 根据记忆结果更新熟练度
    CASE mem_res
        WHEN 1 THEN
            SET current_proficiency = FLOOR(current_proficiency * 0.7 + 100 * 0.3);
        WHEN 2 THEN
            SET current_proficiency = FLOOR(current_proficiency * 0.9);
        WHEN 3 THEN
            SET current_proficiency = FLOOR(current_proficiency * 0.3);
        ELSE
            -- 如果mem_res不是1、2或3，可以设置为默认值或抛出错误
            SET current_proficiency = 0; -- 或者可以选择抛出错误
        END CASE;

    -- 插入或更新memory表中的记录
    INSERT INTO memory (user_id, word_id, last_memory_time, proficiency)
    VALUES (p_user_id, p_word_id, CURDATE(), current_proficiency)
    ON DUPLICATE KEY UPDATE
                         last_memory_time = VALUES(last_memory_time),
                         proficiency = VALUES(proficiency);
END;

