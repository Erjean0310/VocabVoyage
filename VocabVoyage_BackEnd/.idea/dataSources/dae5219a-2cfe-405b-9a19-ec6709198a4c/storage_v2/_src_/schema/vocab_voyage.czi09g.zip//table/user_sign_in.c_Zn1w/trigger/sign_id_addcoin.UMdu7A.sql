create definer = root@`%` trigger sign_id_addcoin
    after update
    on user_sign_in
    for each row
BEGIN
		IF NEW.record <>OLD.record
THEN
			UPDATE user
			SET coin = coin + 1
			WHERE user.id = NEW.user_id;
		END IF;
END;

